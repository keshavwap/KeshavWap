
# You2PHP
----
You2PHP

![https://you2php.github.io/img/11.png](https://you2php.github.io/img/11.png)

# Features
The cost of using You2PHP is very low. You only need a virtual overseas host that supports the PHP environment. Simply upload the code and set it up to use it immediately. Whether you are using a virtual host or a VPS, you can use it after uploading, without a database!

You2PHP connects to Google's official APi, and realizes functions such as video / channel search, online video playback, channel / category content preview, and video download. You do not need to install any software on your device to browse these contents.

You2PHP is released under the GPL open source agreement. You can use and modify the code freely, and you can watch a global video by visiting a URL anytime, anywhere.
# Program screenshot
![https://you2php.github.io/img/11.png](https://you2php.github.io/img/11.png)
![https://you2php.github.io/img/22.png](https://you2php.github.io/img/22.png)
![https://you2php.github.io/img/33.png](https://you2php.github.io/img/33.png)
![https://you2php.github.io/img/55.png](https://you2php.github.io/img/55.png)
Please use this project in compliance with the relevant local laws and regulations

I refuse to provide any technical support for any commercial or illegal purpose

This project is created for researchers to learn knowledge more conveniently, please do not spread it on a large scale
