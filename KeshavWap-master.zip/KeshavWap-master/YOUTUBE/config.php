<?php
define('ROOT_PART', Root_part());
define('APIKEY', '*********************************');//Change it to your api key here
define('GJ_CODE', 'KR');//country code
define('SITE_NAME', 'Youtube');//Website name
define('TITLENAME', 'Youtube');//Website name
define('EN2DEKEY', 'AnQUP1XDEF435e67CtzDSh4');//一Random strings, encryption and decryption KEY
define('EMAIL', '123@123.com');//mailbox
?>
