<?php
/**
 * Youtube Proxy 
 * Simple Youtube PHP Proxy Server
 * @author ZXQ
 * @version V4.0
 * @description Core operation function set
 */

require_once(dirname(__FILE__).'/config.php');

//Load third-party ytb parsing library
require_once(dirname(__FILE__).'/YouTubeDownloader.php');
//Get remote data function
 function get_data($url){
    if (!function_exists("curl_init")) {
		$f = file_get_contents($url);
	} else {
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 20);
		curl_setopt($ch, CURLOPT_REFERER, 'http://www.youtube.com/');
		curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 5.1) AppleWebKit/534.30 (KHTML, like Gecko) Chrome/12.0.742.91 Safari/534.30");
		$f = curl_exec($ch);
		curl_close($ch);
	}
   return $f;  
}
//Get category popular videos
function get_trending($apikey,$max,$pageToken='',$regionCode='vn'){
    $apilink='https://www.googleapis.com/youtube/v3/videos?part=snippet,contentDetails&chart=mostPopular&regionCode='.$regionCode.'&maxResults='.$max.'&key='.$apikey.'&pageToken='.$pageToken;
     return json_decode(get_data($apilink),true);
}

//Get video data function
 function get_video_info($id,$apikey){
    $apilink='https://www.googleapis.com/youtube/v3/videos?part=snippet,contentDetails,statistics&id='.$id.'&key='.$apikey;
     return json_decode(get_data($apilink),true);
}

//Get user channel data
function get_channel_info($cid,$apikey){
   $apilink='https://www.googleapis.com/youtube/v3/channels?part=snippet,contentDetails,statistics&hl=zh&id='.$cid.'&key='.$apikey;
   return json_decode(get_data($apilink),true);
}

//Get related videos
function get_related_video($vid,$apikey){
   $apilink='https://www.googleapis.com/youtube/v3/search?part=snippet&type=video&maxResults=24&relatedToVideoId='.$vid.'&key='.$apikey;
   return json_decode(get_data($apilink),true);
}


//Get user channel video
function get_channel_video($cid,$pageToken='',$apikey,$regionCode='VN'){
   $apilink='https://www.googleapis.com/youtube/v3/search?order=date&part=snippet&maxResults=50&type=video&regionCode='.$regionCode.'&hl=en-IN&channelId='.$cid.'&key='.$apikey.'&pageToken='.$pageToken;
   return json_decode(get_data($apilink),true);
}

//Get video category content
function videoCategories($apikey,$regionCode='HK'){
   $apilink='https://www.googleapis.com/youtube/v3/videoCategories?part=snippet&regionCode='.$regionCode.'&hl=en-IN&key='.$apikey;
   return json_decode(get_data($apilink),true);
}


function categorieslist($id){
   $data=array(
    '1' => 'Movies and animation',
    '2' => 'car',
    '10' => 'Music',
    '15' => 'Pets and animals',
    '17' => 'Physical education',
    '18' => 'Short film',
    '19' => 'Tours and activities',
    '20' => 'Game',
    '21' => 'Video blog',
    '22' => 'People and Blog',
    '23' => 'Comedy',
    '24' => 'Entertainment',
    '25' => 'News and politics',
    '26' => 'DIY and Life Encyclopedia',
    '27' => 'Education',
    '28' => 'Science and technology',
    '30' => 'The film',
    '31' => 'Anime / animation',
    '32' => 'Action / Adventure',
    '33' => 'Classic',
    '34' => 'Comedy',
    '35' => 'Documentary',
    '36' => 'Drama',
    '37' => 'Family movies',
    '38' => 'Foreign countries',
    '39' => 'Horror film',
    '40' => 'Science fiction / fantasy',
    '41' => 'Horror film',
    '42' => 'Short film',
    '43' => 'Program',
    '44' => 'Trailer'
       );
     if($id=='all'){
     return $data;    
     }else{
      return $data[$id];   
     }
}
//Get video category content
function Categories($id,$apikey,$pageToken='',$order='relevance',$regionCode='VN'){
   $apilink='https://www.googleapis.com/youtube/v3/search?part=snippet&type=video&&regionCode='.$regionCode.'&hl=zh-ZH&maxResults=48&videoCategoryId='.$id.'&key='.$apikey.'&order='.$order.'&pageToken='.$pageToken;
   return json_decode(get_data($apilink),true);
}


//Get search data
function get_search_video($query,$apikey,$pageToken='',$type='video',$order='relevance',$regionCode='VN'){
   $apilink='https://www.googleapis.com/youtube/v3/search?part=snippet&maxResults=48&order='.$order.'&type='.$type.'&q='.$query.'&key='.$apikey.'&pageToken='.$pageToken;
   return json_decode(get_data($apilink),true);
}

//api Return value time conversion function 1
function covtime($youtube_time){
    $start = new DateTime('@0'); 
    $start->add(new DateInterval($youtube_time));
    if(strlen($youtube_time)<=7){
      return $start->format('i:s');  
    }else{
     return $start->format('H:i:s');   
    }
    
}   

//Conversion time function, calculate the release time a few days ago a few years ago
function format_date($time){
    $t=strtotime($time);
    $t=time()-$t;
    $f=array(
    '31536000'=>'Year',
    '2592000'=>'Month',
    '604800'=>'Week',
    '86400'=>'Day',
    '3600'=>'Hour',
    '60'=>'Minute',
    '1'=>'Second'
    );
    foreach ($f as $k=>$v)    {
        if (0 !=$c=floor($t/(int)$k)) {
            return $c.$v.'Ago';
        }
    }
}

//api return value time conversion function 2
function str2time($ts) {
 return date("Y-m-d H:i", strtotime($ts));
}

 //Volume conversion
function convertviewCount($value){
    if($value <= 10000){
    $number = $value;   
    }else{
      $number = $value / 1000 ; 
      $number = round($number,1).'K';
      
    }
    
    return $number;
}
//Get banner background
function get_banner($a,$apikey){
   $apilink='https://www.googleapis.com/youtube/v3/channels?part=brandingSettings&id='.$a.'&key='.$apikey;
   $json=json_decode(get_data($apilink),true);
  if (array_key_exists('bannerTabletImageUrl',$json['items'][0]['brandingSettings']['image'])){
  return $json['items'][0]['brandingSettings']['image']['bannerTabletImageUrl'];    
 }else{
  return 'https://c1.staticflickr.com/5/4546/24706755178_66c375d5ba_h.jpg';   
 }
}
$videotype=array(
    '3GP144P' => array('3GP','144P','3gpp'),
    '360P' => array('MP4','360P','mp4'), 
    '720P' => array('MP4','720P','mp4'), 
    'WebM360P' => array('webM','360P','webm'), 
    'Unknown' => array('N/A','N/A','3gpp'), 
    );
    
//Acquiring related channels API is not supported, it is done by collecting
require_once(dirname(__FILE__).'/inc/phpQuery.php');
require_once(dirname(__FILE__).'/inc/QueryList.php');
use QL\QueryList;
function get_related_channel($id){
    $channel='https://www.youtube.com/channel/'.$id;
    $rules = array(
    'id' => array('.branded-page-related-channels .branded-page-related-channels-list li','data-external-id'),
    'name' => array('.branded-page-related-channels .branded-page-related-channels-list li .yt-lockup .yt-lockup-content .yt-lockup-title a','text'),
);

return $data = QueryList::Query(get_data($channel),$rules)->data;
}

//Collect and crawl random recommendations
function random_recommend(){
   $dat=get_data('https://www.youtube.com/?gl=TW&hl=en-IN'); 
   $rules = array(
    't' => array('#feed .individual-feed .section-list li .item-section li .feed-item-container .feed-item-dismissable .shelf-title-table .shelf-title-row h2 .branded-page-module-title-text','text'),
    'html' => array('#feed .individual-feed .section-list li .item-section li .feed-item-container .feed-item-dismissable .compact-shelf .yt-viewport .yt-uix-shelfslider-list','html'),
        );

    $rules1 = array(
    'id' => array('li .yt-lockup ','data-context-item-id'),
    'title' => array('li .yt-lockup .yt-lockup-dismissable .yt-lockup-content .yt-lockup-title a','text'),
        );

    $data = QueryList::Query($dat,$rules)->data;
    
    $ldata=array();
    foreach ($data as $v) {
       $d = QueryList::Query($v['html'],$rules1)->data;
       $ldata[]=array(
           't'=> $v['t'],
           'dat' => $d
           );
    }
    array_shift($ldata);
    return $ldata;
}
//Video download
function video_down($v,$name){
$yt = new YouTubeDownloader();
$links = $yt->getDownloadLinks("https://www.youtube.com/watch?v=$v");
echo '<table class="table table-hover"><thead><tr>
      <th>Format</th>
      <th>Types of</th>
      <th>Download</th>
    </tr>
  </thead>';
foreach ($links as $value) {
    global $videotype;
echo ' <tbody>
    <tr>
      
      <td>'.$videotype[$value['format']][0].'</td>
      <td>'.$videotype[$value['format']][1].'</td>
      <td><a href="./downvideo.php?v='.$v.'&quality='.$value['format'].'&name='.$name.'&format='.$videotype[$value['format']][2].'" target="_blank" class="btn btn-outline-success btn-sm">下载</a></td>
    </tr></tbody>';
    } 
    echo '</table>';
}

//Determine if HD thumbnails exist
function get_thumbnail_code($vid){
$thumblink='https://img.youtube.com/vi/'.$vid.'/maxresdefault.jpg';    
$oCurl = curl_init();
$header[] = "Content-type: application/x-www-form-urlencoded";
$user_agent = "Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.146 Safari/537.36";
curl_setopt($oCurl, CURLOPT_URL, $thumblink);
curl_setopt($oCurl, CURLOPT_HTTPHEADER,$header);
curl_setopt($oCurl, CURLOPT_HEADER, true);
curl_setopt($oCurl, CURLOPT_NOBODY, true);
curl_setopt($oCurl, CURLOPT_USERAGENT,$user_agent);
curl_setopt($oCurl, CURLOPT_RETURNTRANSFER, 1 );
curl_setopt($oCurl, CURLOPT_POST, false);
$sContent = curl_exec($oCurl);
$headerSize = curl_getinfo($oCurl, CURLINFO_HTTP_CODE);
curl_close($oCurl);
if($headerSize == '404'){
  return 'https://img.youtube.com/vi/'.$vid.'/hqdefault.jpg';  
}else{
  return 'https://img.youtube.com/vi/'.$vid.'/maxresdefault.jpg';   
}
}


//Parsing history
function Hislist($str,$apikey){
    $str=str_replace('@',',',$str);
    $apilink='https://www.googleapis.com/youtube/v3/videos?part=snippet,contentDetails&id='.$str.'&key='.$apikey;
   return json_decode(get_data($apilink),true);   
}

//Get Channel Country
$CountryID=array(
    'DZ' => 'Algeria',
    'AR' => 'Argentina',
    'AE' => 'United arab emirates',
    'OM' => 'Oman',
    'AZ' => 'Azerbaijan',
    'EG' => 'Egypt',
    'IE' => 'Ireland',
    'EE' => 'Estonia',
    'AT' => 'Austria',
    'AU' => 'Australia',
    'PK' => 'Pakistan',
    'BH' => 'Bahrain',
    'BR' => 'Brazil',
    'BY' => 'Belarus',
    'BG' => 'Bulgaria',
    'BE' => 'Belgium',
    'IS' => 'Iceland',
    'PR' => 'Puerto Rico',
    'PL' => 'Poland',
    'BA' => 'Bosnia and Herzegovina',
    'DK' => 'Denmark',
    'DE' => 'Germany',
    'RU' => 'Russia',
    'FR' => 'France',
    'PH' => 'Philippines',
    'FI' => 'Finland',
    'CO' => 'Colombia',
    'GE' => 'Georgia',
    'KZ' => 'Kazakhstan',
    'KR' => 'Korea',
    'NL' => 'Netherlands',
    'ME' => 'Montenegro',
    'CA' => 'Canada',
    'CN' => 'China',
    'GH' => 'Ghana',
    'CZ' => 'Czech Republic',
    'ZW' => 'Zimbabwe',
    'QA' => 'Qatar',
    'KW' => 'Kuwait',
    'HR' => 'Croatia',
    'KE' => 'Kenya',
    'LV' => 'Latvia',
    'LB' => 'Lebanon',
    'LT' => 'Lithuania',
    'LY' => 'Libya',
    'LU' => 'Principality of Luxembourg',
    'RO' => 'Romania',
    'MY' => 'Malaysia',
    'MK' => 'Macedonia',
    'US' => 'United States',
    'PE' => 'Peru',
    'MA' => 'Morocco',
    'MX' => 'Mexico',
    'ZA' => 'South Africa',
    'NP' => 'Nepal',
    'NG' => 'Nigeria',
    'NO' => 'Norway',
    'PT' => 'Portugal',
    'JP' => 'Japan',
    'SE' => 'Sweden',
    'CH' => 'Switzerland',
    'RS' => 'Serbia',
    'SN' => 'Senegal',
    'SA' => 'Saudi Arabia',
    'LK' => 'Sri Lanka',
    'SK' => 'Slovakia',
    'SI' => 'Slovenia',
    'TW' => 'Taiwan',
    'TH' => 'Thailand',
    'TZ' => 'Tanzania',
    'TN' => 'Tunisia',
    'TR' => 'Turkey',
    'UG' => 'Uganda',
    'UA' => 'Ukraine',
    'ES' => 'Spain',
    'GR' => 'Greece',
    'HK' => 'Hong Kong',
    'SG' => 'Singapore',
    'NZ' => 'new Zealand',
    'HU' => 'Hungary',
    'JM' => 'Jamaica',
    'YE' => 'Yemen',
    'IQ' => 'Iraq',
    'IL' => 'Israel',
    'IT' => 'Italy',
    'IN' => 'India',
    'ID' => 'Indonesia',
    'GB' => 'United Kingdom',
    'JO' => 'Jordan',
    'VN' => 'Vietnam',
    'CL' => 'Chile',
    );
function get_country($c){
    global $CountryID;
    return  $CountryID[$c];
}

//url String encryption and decryption
function strencode($string,$key='09KxDsIIe|+]8Fo{YP<l+3!y#>a$;^PzFpsxS9&d;!l;~M>2?N7G}`@?UJ@{FDI') {
    $key = sha1($key);
    $strLen = strlen($string);
    $keyLen = strlen($key);
    for ($i = 0; $i < $strLen; $i++) {
        $ordStr = ord(substr($string,$i,1));
        if (@$j == $keyLen) { $j = 0; }
        $ordKey = ord(substr($key,$j,1));
        @$j++;
    @$hash .= strrev(base_convert(dechex($ordStr + $ordKey),16,36));
    }
    return 'Urls://'.$hash;
}
function strdecode($string,$key='09KxDsIIe|+]8Fo{YP<l+3!y#>a$;^PzFpsxS9&d;!l;~M>2?N7G}`@?UJ@{FDI') {
    $string= ltrim($string, 'Urls://');
    $key = sha1($key);
    $strLen = strlen($string);
    $keyLen = strlen($key);
    for ($i = 0; $i < $strLen; $i+=2) {
        $ordStr = hexdec(base_convert(strrev(substr($string,$i,2)),36,16));
        if (@$j == $keyLen) { @$j = 0; }
        $ordKey = ord(substr($key,@$j,1));
        @$j++;
        @$hash .= chr($ordStr - $ordKey);
    }
    return $hash;
}

//Sharing function
function shareit($id,$title='Wall-free Youtube mirroring'){
    $pic=ROOT_PART.'/thumbnail.php?vid='.$id;
    $url=ROOT_PART.'watch-'.$id.'.html';
    $title=str_replace('&','||',$title);
    $title=str_replace('"',' ',$title);
     $title=str_replace("'",' ',$title);
    $des='【Wall-free Youtube mirroring】I am watching through this website《'.$title.'》No need to watch the global video，Can be seen on mobile computers，Come try it out！';
    return "<div id='share'>
  <a class='icoqz' href='https://sns.qzone.qq.com/cgi-bin/qzshare/cgi_qzshare_onekey?url=".$url."&desc=".$des."&title=".$titlel."
&pics=".$pic."' target='blank' title='Share to QQ space'><i class='iconfont icon-qqkongjian icofontsize'></i></a>

  <a class='icotb' href='http://tieba.baidu.com/f/commit/share/openShareApi?title=".$title."&url=".$url."&to=tieba&type=text&relateUid=&pic=".$pic."&key=&sign=on&desc=&comment=".$title."' target='blank' title='Share to post'><i class='iconfont icon-40 icofontsize'></i></a>

  <a class='icowb' href='http://service.weibo.com/share/share.php?url=".$url."&title=".$des."&pic=".$pic."&sudaref=".$title."' target='blank' title='Share to Weibo'><i class='iconfont icon-weibo icofontsize'></i></a>

  <a class='icobi' href='https://member.bilibili.com/v/#/text-edit' target='blank' title='Share to Bilibili'><i class='iconfont icon-bilibili icofontsize'></i></a>

  <a class='icowx' href='http://api.addthis.com/oexchange/0.8/forward/wechat/offer?url=".ROOT_PART."watch.php?v=".$id."' target='blank' title='Share on WeChat' ><i class='iconfont icon-weixin icofontsize'></i></a>
</div>
 <div class='form-group'><div class='d-inline-block h6 pt-3 col-12'>
    Share code：
 </div>
    <textarea style='resize:none;height: auto' class='form-control d-inline align-middle col-12 icoys icontext' id='inputs' type='text' rows='5' placeholder='Default input'><iframe height=498 width=510 src=&quot;".ROOT_PART."embed/?v=".$id.";&quot; frameborder=0 &quot;allowfullscreen&quot;></iframe></textarea>
    
    <button type='submit' class='btn btn-primary align-middle col-12 mt-2' onclick='copytext1()'>Copy</button></div>";
    
}
//
function html5_player($id){
    $yt = new YouTubeDownloader();
    $links = $yt->getDownloadLinks('https://www.youtube.com/watch?v='.$id);
    if(count($links)!=1){
        echo'<video id="h5player"  class="video-js vjs-fluid mh-100 mw-100" loop="loop" width="100%" preload="auto"  webkit-playsinline="true" playsinline="true" x-webkit-airplay="true" controls="controls" controls preload="auto" width="100%" poster="./thumbnail.php?type=maxresdefault&vid='.$id.'" data-setup=\'\'>';
        
        //Get video resolution
        if(array_key_exists('22',$links)){
        echo '<source src="./vs.php?vv='.$id.'&quality=720" type=\'video/mp4\' res="720" label=\'720P\'/>';   
            };
        echo '<source src="./vs.php?vv='.$id.'&quality=360" type=\'video/mp4\' res="360" label=\'360P\'/>';
        
        
    //Extract subtitles
     $slink='https://www.youtube.com/api/timedtext?type=list&v='.$id;
     $vdata=get_data($slink);
     @$xml = simplexml_load_string($vdata);
     $array1=json_decode(json_encode($xml), true);
     $arr=array();
     //Separate several common subtitles
     if(array_key_exists('track',$array1) && array_key_exists('0',$array1['track'])){
         if (array_key_exists('track', $array1) && array_key_exists('0', $array1['track'
    									   ])) {
    	foreach ($array1['track'] as $val) {if ($val['@attributes']['lang_code'] == 'en' || $val['@attributes']['lang_code'] == 'zh' || $val['@attributes']['lang_code'] =='en-IN' || $val['@attributes']['lang_code'] =='zh-TW' || $val['@attributes']['lang_code'] =='zh-HK') {
    			$arr[$val['@attributes']['lang_code']] = "
    <track kind='captions' src='./tracks.php?vtt={$id}&lang=" . $val['@attributes']
    ['lang_code'] . "' srclang='" . $val['@attributes']['lang_code'] . "' label='" .
    				   $val['@attributes']['lang_original'] . "'/>";
    		}
    	}
    	foreach ($arr as $k => $v) {
    	    switch ($k) {
    		    case 'en-IN':
    		        $arr[$k] = substr_replace($v, ' default ', -2,0);
    				break;
    			case 'zh':
    		        $arr[$k] = substr_replace($v, ' default ', -2,0);
    				break;
    			case 'zh-HK':
    		        $arr[$k] = substr_replace($v, ' default ', -2,0);
    				break;
    			case 'zh-TW':
    				$arr[$k] = substr_replace($v, ' default ', -2,0);
    				break;
    			case 'en':
    				$arr[$k] = substr_replace($v, ' default ', -2,0);
    				break;
    		}
    		break;
    	}
    	foreach($arr as $vl ){
          echo $vl.PHP_EOL;
      }
    }
     }elseif(array_key_exists('track',$array1)){
     echo "<track kind='captions' src='./tracks.php?vtt={$id}&lang=".$array1['track']['@attributes']['lang_code']."' srclang='".$array1['code']."' label='".$array1['track']['@attributes']['lang_original']."' default />";   
     }

    echo '</video>';
    }else{
        echo '<img src="./inc/2.svg" class="w-100" onerror="this.onerror=null; this.src="./inc/2.gif"">';       
        }   
}
//Get installation directory
function Root_part(){
$http=isset($_SERVER['HTTPS']) ? 'https://' : 'http://';
$part=rtrim($_SERVER['SCRIPT_NAME'],basename($_SERVER['SCRIPT_NAME']));
$domain=$_SERVER['SERVER_NAME'];
 return "$http"."$domain"."$part";
}
?>
